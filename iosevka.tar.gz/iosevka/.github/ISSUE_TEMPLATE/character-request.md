---
name: Character Request
about: Request Iosevka to support a character
title: ''
labels: "\U0001F170️ Character Request"
assignees: ''

---

- The requested character is...
  - [ ] Latin
  - [ ] Cyrillic
  - [ ] Greek
  - [ ] Punctuation
  - [ ] Symbol
- [ ] Some other monospace/programming fonts supported this character. Provide images below.

------

*Please provide justification here.*
