---
name: Ligation Request
about: Request Iosevka to support a ligation
title: ''
labels: "\U0001F587️ Ligation Request"
assignees: ''

---

- [ ] A programming language requires this ligation. Provide the information below.
- [ ] This ligation is implemented in other programming fonts. Provide samples below.

------

*Please provide justification here.*
