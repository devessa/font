export const light = {
	body: "#20242E",
	dimmed: "#20242E40",
	stress: "#048FBF",
	title: "#8757AD"
};
export const dark = {
	body: "#DEE4E3",
	dimmed: "#DEE4E340",
	stress: "#03AEE9",
	title: "#B77FDB"
};
