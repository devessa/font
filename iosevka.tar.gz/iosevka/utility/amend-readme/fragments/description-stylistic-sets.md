* `inherits`: Optional, String, defines the inherited stylistic set. Valid options include:
