### Packaging Reorganization

Since Iosevka 3.0.0-rc.1, the following packaging reorganization is introduced:

 * `Iosevka Term` → `Iosevka Fixed`.
 * `Iosevka TermLig` → `Iosevka Term`.
 * `Iosevka Type` → Removed.
 * `Iosevka CC` → Removed.

The default Iosevka family's spacing is also updated to focus on code editing solely.